class WordScrambleGame {
    constructor() {
        // Game state
        this.score = 0;
        this.level = 1;
        this.timeLeft = 60;
        this.timerInterval = null;
        this.currentWord = '';
        this.hintsLeft = 3;
        
        // Word lists by level
        this.words = {
            1: [
                { word: 'STUDY', hint: 'Process of learning' },
                { word: 'BOOK', hint: 'Contains knowledge' },
                { word: 'NOTE', hint: 'Write this during class' },
                { word: 'READ', hint: 'Look at and comprehend text' },
                { word: 'MIND', hint: 'Where thoughts happen' },
                { word: 'QUIZ', hint: 'Short test of knowledge' },
                { word: 'MATH', hint: 'Numbers and calculations' },
                { word: 'DESK', hint: 'Where you study' },
                { word: 'PEN', hint: 'Writing tool' },
                { word: 'TASK', hint: 'Work to be done' }
            ],
            2: [
                { word: 'LEARN', hint: 'Acquire knowledge' },
                { word: 'FOCUS', hint: 'Pay attention to' },
                { word: 'THINK', hint: 'Use your brain' },
                { word: 'WRITE', hint: 'Put words on paper' },
                { word: 'BRAIN', hint: 'Center of thinking' },
                { word: 'PAPER', hint: 'Write on this' },
                { word: 'GRADE', hint: 'Mark of achievement' },
                { word: 'CLASS', hint: 'Learning session' },
                { word: 'SMART', hint: 'Intelligent' },
                { word: 'SOLVE', hint: 'Find the answer' }
            ],
            3: [
                { word: 'REVIEW', hint: 'Go over again' },
                { word: 'MEMORY', hint: 'Ability to remember' },
                { word: 'PRACTICE', hint: 'Repeat to improve' },
                { word: 'EXAMINE', hint: 'Look at carefully' },
                { word: 'SCIENCE', hint: 'Study of natural world' },
                { word: 'LIBRARY', hint: 'Place full of books' },
                { word: 'TEACHER', hint: 'Education guide' },
                { word: 'STUDENT', hint: 'Person who learns' },
                { word: 'COLLEGE', hint: 'Higher education' },
                { word: 'LECTURE', hint: 'Educational talk' }
            ],
            4: [
                { word: 'RESEARCH', hint: 'Detailed investigation' },
                { word: 'HOMEWORK', hint: 'Study tasks for home' },
                { word: 'LEARNING', hint: 'Knowledge acquisition' },
                { word: 'QUESTION', hint: 'Something to answer' },
                { word: 'ACADEMIC', hint: 'Related to education' },
                { word: 'TEXTBOOK', hint: 'Educational material' },
                { word: 'SEMESTER', hint: 'Study period' },
                { word: 'GRADUATE', hint: 'Complete studies' },
                { word: 'SCHEDULE', hint: 'Time organization' },
                { word: 'PROGRESS', hint: 'Moving forward' }
            ],
            5: [
                { word: 'EDUCATION', hint: 'Learning process' },
                { word: 'KNOWLEDGE', hint: 'What you know' },
                { word: 'PROFESSOR', hint: 'University teacher' },
                { word: 'CHEMISTRY', hint: 'Study of substances' },
                { word: 'PHYSICS', hint: 'Study of matter and energy' },
                { word: 'BIOLOGY', hint: 'Study of life' },
                { word: 'LANGUAGE', hint: 'Communication system' },
                { word: 'HISTORY', hint: 'Study of past events' },
                { word: 'GEOMETRY', hint: 'Study of shapes' },
                { word: 'ALGEBRA', hint: 'Advanced mathematics' }
            ]
        };

        // DOM elements
        this.elements = {
            scrambledWord: document.getElementById('scrambledWord'),
            wordHint: document.getElementById('wordHint'),
            userGuess: document.getElementById('userGuess'),
            submitBtn: document.getElementById('submitBtn'),
            newWordBtn: document.getElementById('newWordBtn'),
            hintBtn: document.getElementById('hintBtn'),
            score: document.getElementById('score'),
            timer: document.getElementById('timer'),
            level: document.getElementById('level'),
            feedback: document.getElementById('feedback'),
            levelModal: document.getElementById('levelModal'),
            finalScore: document.getElementById('finalScore'),
            timeBonus: document.getElementById('timeBonus'),
            nextLevelBtn: document.getElementById('nextLevelBtn')
        };

        // Bind event listeners
        this.elements.submitBtn.addEventListener('click', () => this.checkAnswer());
        this.elements.newWordBtn.addEventListener('click', () => this.newWord());
        this.elements.hintBtn.addEventListener('click', () => this.showHint());
        this.elements.nextLevelBtn.addEventListener('click', () => this.nextLevel());
        this.elements.userGuess.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.checkAnswer();
        });

        // Start game
        this.initializeGame();
    }

    initializeGame() {
        this.score = 0;
        this.timeLeft = 60 + (this.level - 1) * 15; // Adjust initial time based on level
        this.updateDisplay();
        this.newWord();
        this.startTimer();
    }

    scrambleWord(word) {
        let scrambled = word.split('').sort(() => Math.random() - 0.5).join('');
        // Make sure scrambled word is different from original
        while (scrambled === word && word.length > 1) {
            scrambled = word.split('').sort(() => Math.random() - 0.5).join('');
        }
        return scrambled;
    }

    newWord() {
        const levelWords = this.words[this.level];
        const wordObj = levelWords[Math.floor(Math.random() * levelWords.length)];
        this.currentWord = wordObj.word;
        this.currentHint = wordObj.hint;
        
        this.elements.scrambledWord.textContent = this.scrambleWord(this.currentWord);
        this.elements.wordHint.textContent = 'Hint: ' + wordObj.hint;
        this.elements.userGuess.value = '';
        this.elements.feedback.textContent = '';
        this.elements.userGuess.focus();
    }

    checkAnswer() {
        const guess = this.elements.userGuess.value.toUpperCase();
        
        if (guess === this.currentWord) {
            this.score += 10;
            this.elements.feedback.textContent = 'Correct! +10 points';
            this.elements.feedback.className = 'text-lg font-medium text-green-600';
            this.updateDisplay();
            this.newWord();
        } else {
            this.elements.feedback.textContent = 'Try again!';
            this.elements.feedback.className = 'text-lg font-medium text-red-600';
            this.elements.userGuess.value = '';
        }
    }

    showHint() {
        if (this.hintsLeft > 0) {
            this.hintsLeft--;
            this.elements.wordHint.textContent = `First letter: ${this.currentWord[0]}`;
            this.elements.hintBtn.disabled = true;
        }
    }

    startTimer() {
        this.timerInterval = setInterval(() => {
            this.timeLeft--;
            this.updateDisplay();
            
            if (this.timeLeft <= 0) {
                this.endLevel();
            }
        }, 1000);
    }

    updateDisplay() {
        this.elements.score.textContent = this.score;
        this.elements.timer.textContent = `${Math.floor(this.timeLeft / 60)}:${(this.timeLeft % 60).toString().padStart(2, '0')}`;
        this.elements.level.textContent = this.level;
    }

    endLevel() {
        clearInterval(this.timerInterval);
        const timeBonus = Math.max(0, this.timeLeft);
        const totalScore = this.score + timeBonus;
        
        this.elements.finalScore.textContent = this.score;
        this.elements.timeBonus.textContent = timeBonus;
        this.elements.levelModal.classList.remove('hidden');
    }

    nextLevel() {
        if (this.level < Object.keys(this.words).length) {
            this.level++;
            // Increase time for higher levels
            this.timeLeft = 60 + (this.level - 1) * 15; // 60s, 75s, 90s, 105s, 120s
            this.hintsLeft = 3;
            this.elements.levelModal.classList.add('hidden');
            this.elements.hintBtn.disabled = false;
            this.updateDisplay();
            this.newWord();
            this.startTimer();
        } else {
            // Game complete
            alert('Congratulations! You\'ve completed all levels! 🎉\nFinal Score: ' + this.score);
            this.level = 1;
            this.initializeGame();
        }
    }
}

// Initialize game when page loads
document.addEventListener('DOMContentLoaded', () => {
    new WordScrambleGame();
}); 