document.addEventListener('DOMContentLoaded', () => {
    // Get data from localStorage
    const studyAnalytics = JSON.parse(localStorage.getItem('studyAnalytics')) || {};
    const completedTasks = JSON.parse(localStorage.getItem('completedTasks')) || [];
    const moodHistory = JSON.parse(localStorage.getItem('moodHistory')) || [];

    // Update total stats
    updateTotalStats(studyAnalytics, completedTasks);
    
    // Create charts
    createWeeklyChart(studyAnalytics);
    createMoodChart(moodHistory);
});

// Copy of moodData from tasks.js
const moodData = {
    Happy: {
        tasks: [
            {
                title: "Deep Work Session",
                time: "10 secs"
            },
            {
                title: "Group Study",
                time: "60 mins"
            },
            {
                title: "New Topic Introduction",
                time: "30 mins"
            }
        ]
    },
    Stressed: {
        tasks: [
            {
                title: "Quick Review Session",
                time: "20 mins"
            },
            {
                title: "Mindful Break",
                time: "10 mins"
            },
            {
                title: "Organization Task",
                time: "15 mins"
            }
        ]
    },
    Tired: {
        tasks: [
            {
                title: "Easy Topic Review",
                time: "15 secs"
            },
            {
                title: "Active Learning",
                time: "30 mins"
            },
            {
                title: "Mind Mapping",
                time: "20 mins"
            }
        ]
    },
    Focused: {
        tasks: [
            {
                title: "Complex Problem Solving",
                time: "50 mins"
            },
            {
                title: "Critical Analysis",
                time: "45 mins"
            },
            {
                title: "Content Creation",
                time: "40 mins"
            }
        ]
    }
};

function updateTotalStats(studyAnalytics, completedTasks) {
    // Update total tasks
    document.getElementById('totalTasks').textContent = completedTasks.length;

    // Calculate total study time
    let totalMinutes = 0;
    Object.values(studyAnalytics).forEach(day => {
        totalMinutes += day.minutes || 0;
    });

    // Convert to hours and minutes
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    document.getElementById('studyTime').textContent = 
        `${hours}h ${minutes}m`;

    // Calculate streak
    const streak = calculateStreak(studyAnalytics);
    document.getElementById('dailyStreak').textContent = streak;
}

function calculateStreak(analytics) {
    const today = new Date().toISOString().split('T')[0];
    const dates = Object.keys(analytics).sort((a, b) => b.localeCompare(a));
    
    if (dates.length === 0) return 0;
    
    // Check if studied today or yesterday
    const lastStudyDate = dates[0];
    const lastStudyDay = new Date(lastStudyDate);
    const todayDate = new Date(today);
    const diffDays = Math.floor((todayDate - lastStudyDay) / (1000 * 60 * 60 * 24));
    
    if (diffDays > 1) return 0;
    
    let streak = 1;
    for (let i = 0; i < dates.length - 1; i++) {
        const currentDate = new Date(dates[i]);
        const nextDate = new Date(dates[i + 1]);
        const dayDiff = Math.floor((currentDate - nextDate) / (1000 * 60 * 60 * 24));
        
        if (dayDiff === 1) {
            streak++;
        } else {
            break;
        }
    }
    
    return streak;
}

function createWeeklyChart(analytics) {
    const ctx = document.getElementById('weeklyChart');
    if (!ctx) return;

    const weeklyData = {
        labels: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        datasets: [{
            label: 'Study Sessions',
            data: new Array(7).fill(0),
            backgroundColor: '#818CF8'
        }]
    };

    // Fill in actual data
    Object.entries(analytics).forEach(([date, data]) => {
        const day = new Date(date).getDay();
        weeklyData.datasets[0].data[day] = data.sessions || 0;
    });

    new Chart(ctx, {
        type: 'bar',
        data: weeklyData,
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } }
        }
    });
}

function createMoodChart(moodHistory) {
    const ctx = document.getElementById('moodChart');
    if (!ctx) return;

    const moodData = {
        labels: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        datasets: [
            {
                label: 'Happy',
                data: new Array(7).fill(0),
                backgroundColor: '#10B981'
            },
            {
                label: 'Focused',
                data: new Array(7).fill(0),
                backgroundColor: '#6366F1'
            },
            {
                label: 'Tired',
                data: new Array(7).fill(0),
                backgroundColor: '#8B5CF6'
            }
        ]
    };

    // Fill in actual data
    moodHistory.forEach(entry => {
        const day = new Date(entry.date).getDay();
        const moodIndex = moodData.datasets.findIndex(ds => ds.label === entry.mood);
        if (moodIndex >= 0) {
            moodData.datasets[moodIndex].data[day]++;
        }
    });

    new Chart(ctx, {
        type: 'bar',
        data: moodData,
        options: {
            responsive: true,
            scales: {
                x: { stacked: true },
                y: { stacked: true, beginAtZero: true }
            }
        }
    });
}

function getMoodColor(mood) {
    const colors = {
        Happy: '#10B981',
        Focused: '#6366F1',
        Energetic: '#F59E0B',
        Tired: '#8B5CF6',
        Stressed: '#EF4444',
        Anxious: '#EC4899'
    };
    return colors[mood] || '#6B7280';
}

// Save mood to history when completing tasks
function saveMoodToHistory(mood) {
    const moodHistory = JSON.parse(localStorage.getItem('moodHistory')) || [];
    moodHistory.push({
        mood: mood,
        date: new Date().toISOString().split('T')[0],
        timestamp: new Date().toISOString()
    });
    localStorage.setItem('moodHistory', JSON.stringify(moodHistory));
}

// Update the existing analyticsUpdated event listener
window.addEventListener('analyticsUpdated', (event) => {
    const { date, sessions, minutes } = event.detail;
    
    // Update all analytics displays
    const studyAnalytics = JSON.parse(localStorage.getItem('studyAnalytics')) || {};
    const completedTasks = JSON.parse(localStorage.getItem('completedTasks')) || [];
    const moodHistory = JSON.parse(localStorage.getItem('moodHistory')) || [];
    
    updateTotalStats(studyAnalytics, completedTasks);
    createWeeklyChart(studyAnalytics);
    createMoodChart(moodHistory);
}); 