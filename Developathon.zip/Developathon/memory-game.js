class MemoryGame {
    constructor() {
        this.cards = [];
        this.flippedCards = [];
        this.matchedPairs = 0;
        this.moves = 0;
        this.gameStarted = false;
        this.timer = 0;
        this.timerInterval = null;
        
        // Game elements
        this.boardElement = document.getElementById('gameBoard');
        this.movesElement = document.getElementById('moves');
        this.pairsElement = document.getElementById('pairs');
        this.timerElement = document.getElementById('timer');
        this.winModal = document.getElementById('winModal');
        
        // Bind event listeners
        document.getElementById('newGameBtn').addEventListener('click', () => this.startNewGame());
        document.getElementById('playAgainBtn').addEventListener('click', () => {
            this.winModal.classList.add('hidden');
            this.startNewGame();
        });
    }

    initializeCards() {
        const emojis = ['🎮', '📚', '🎵', '🌟', '🎨', '🎪'];
        this.cards = [...emojis, ...emojis]
            .sort(() => Math.random() - 0.5)
            .map((emoji, index) => ({
                id: index,
                emoji: emoji,
                isFlipped: false,
                isMatched: false
            }));
    }

    createCardElement(card) {
        const cardElement = document.createElement('div');
        cardElement.className = 'memory-card';
        cardElement.dataset.id = card.id;
        
        cardElement.innerHTML = `
            <div class="memory-card-inner">
                <div class="memory-card-front">
                    ${card.emoji}
                </div>
                <div class="memory-card-back">
                    <svg class="w-8 h-8 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                </div>
            </div>
        `;

        cardElement.addEventListener('click', () => this.flipCard(card));
        return cardElement;
    }

    flipCard(card) {
        if (!this.gameStarted) {
            this.startTimer();
            this.gameStarted = true;
        }
        
        if (this.flippedCards.length === 2 || card.isMatched || card.isFlipped) return;

        card.isFlipped = true;
        this.flippedCards.push(card);
        
        const cardElement = this.boardElement.querySelector(`[data-id="${card.id}"]`);
        cardElement.classList.add('flipped');

        if (this.flippedCards.length === 2) {
            this.moves++;
            this.movesElement.textContent = this.moves;
            this.checkMatch();
        }
    }

    checkMatch() {
        const [card1, card2] = this.flippedCards;
        const match = card1.emoji === card2.emoji;

        setTimeout(() => {
            if (match) {
                card1.isMatched = card2.isMatched = true;
                this.matchedPairs++;
                this.pairsElement.textContent = `${this.matchedPairs}/6`;
                
                if (this.matchedPairs === 6) {
                    this.endGame();
                }
            } else {
                card1.isFlipped = card2.isFlipped = false;
                const elements = this.boardElement.querySelectorAll(
                    `[data-id="${card1.id}"], [data-id="${card2.id}"]`
                );
                elements.forEach(el => el.classList.remove('flipped'));
            }
            this.flippedCards = [];
        }, 1000);
    }

    startTimer() {
        this.timerInterval = setInterval(() => {
            this.timer++;
            const minutes = Math.floor(this.timer / 60);
            const seconds = this.timer % 60;
            this.timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }, 1000);
    }

    endGame() {
        clearInterval(this.timerInterval);
        document.getElementById('finalMoves').textContent = this.moves;
        document.getElementById('finalTime').textContent = this.timerElement.textContent;
        this.winModal.classList.remove('hidden');
    }

    startNewGame() {
        this.boardElement.innerHTML = '';
        this.matchedPairs = 0;
        this.moves = 0;
        this.timer = 0;
        this.gameStarted = false;
        this.flippedCards = [];
        
        clearInterval(this.timerInterval);
        this.timerElement.textContent = '0:00';
        this.movesElement.textContent = '0';
        this.pairsElement.textContent = '0/6';

        this.initializeCards();
        this.cards.forEach(card => {
            this.boardElement.appendChild(this.createCardElement(card));
        });
    }
}

// Initialize game when page loads
document.addEventListener('DOMContentLoaded', () => {
    const game = new MemoryGame();
    game.startNewGame();
}); 