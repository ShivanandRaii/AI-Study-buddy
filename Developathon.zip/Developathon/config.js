// Import the functions you need from the SDKs
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';
import { getAnalytics } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-analytics.js';

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAMBRt5n42iWPRFYqXWsVYMyt38JxdXrSc",
    authDomain: "moodstudy-8bd0f.firebaseapp.com",
    projectId: "moodstudy-8bd0f",
    storageBucket: "moodstudy-8bd0f.firebasestorage.app",
    messagingSenderId: "294805089225",
    appId: "1:294805089225:web:b09fa5b0483a3391c19618",
    measurementId: "G-85KEN2FPS3"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const analytics = getAnalytics(app);