const DEEPSEEK_API_KEY = 'Bearer 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';
const AI_API_URL = 'https://api.deepseek.com/v1/chat/completions';

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  // Handle CORS preflight requests
  if (request.method === "OPTIONS") {
    return new Response(null, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "*",
        "Access-Control-Max-Age": "86400"
      }
    });
  }

  if (request.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  try {
    const reqBody = await request.json();
    console.log('Received request:', reqBody);

    const aiResponse = await fetch(AI_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: reqBody.messages,
        temperature: 0.7,
        max_tokens: 2000
      })
    });

    const responseText = await aiResponse.clone().text();
    console.log('Raw AI Response:', responseText);

    const data = await aiResponse.json();
    console.log('Parsed AI Response:', data);

    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        throw new Error('Rate limit exceeded. Please wait a moment before trying again.');
      }
      if (aiResponse.status === 401) {
        throw new Error('API authentication failed. Please check your API key.');
      }
      throw new Error(`API responded with status ${aiResponse.status}: ${JSON.stringify(data)}`);
    }

    if (!data || !data.choices || !data.choices[0]) {
      console.error('Invalid API response:', data);
      throw new Error('Invalid response from AI service');
    }

    return new Response(JSON.stringify(data), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': "*",
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
      }
    });
  } catch (error) {
    console.error('Error:', error);
    const errorResponse = {
      error: error.message,
      details: error.message
    };
    return new Response(JSON.stringify(errorResponse), {
      status: error.message.includes('Rate limit') ? 429 : 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': "*",
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
      }
    });
  }
} 