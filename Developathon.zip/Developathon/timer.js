class StudyTimer {
    constructor() {
        // Timer state
        this.timeLeft = 25 * 60; // 25 minutes in seconds
        this.isRunning = false;
        this.timerInterval = null;
        this.totalSessions = 0;
        this.totalMinutes = 0;

        // DOM elements
        this.elements = {
            timer: document.getElementById('timer'),
            startBtn: document.getElementById('startBtn'),
            pauseBtn: document.getElementById('pauseBtn'),
            resetBtn: document.getElementById('resetBtn'),
            totalSessions: document.getElementById('totalSessions'),
            totalTime: document.getElementById('totalTime'),
            customMinutes: document.getElementById('customMinutes'),
            customSeconds: document.getElementById('customSeconds'),
            setTimeBtn: document.getElementById('setTimeBtn')
        };

        // Bind event listeners
        this.elements.startBtn.addEventListener('click', () => this.startTimer());
        this.elements.pauseBtn.addEventListener('click', () => this.pauseTimer());
        this.elements.resetBtn.addEventListener('click', () => this.resetTimer());

        // Time preset buttons
        document.querySelectorAll('.time-preset-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const minutes = parseInt(btn.dataset.time);
                this.setTime(minutes);
            });
        });

        // Add custom time event listener
        this.elements.setTimeBtn.addEventListener('click', () => this.setCustomTime());

        // Add input validation
        this.elements.customMinutes.addEventListener('input', function() {
            if (this.value < 0) this.value = 0;
            if (this.value > 180) this.value = 180;
        });

        this.elements.customSeconds.addEventListener('input', function() {
            if (this.value < 0) this.value = 0;
            if (this.value > 59) this.value = 59;
        });

        // Initialize display
        this.updateDisplay();

        // Initialize analytics from localStorage
        this.loadAnalytics();
    }

    startTimer() {
        if (!this.isRunning) {
            this.isRunning = true;
            this.elements.startBtn.disabled = true;
            this.elements.pauseBtn.disabled = false;
            
            this.timerInterval = setInterval(() => {
                this.timeLeft--;
                this.updateDisplay();

                if (this.timeLeft <= 0) {
                    this.completeSession();
                }
            }, 1000);
        }
    }

    pauseTimer() {
        if (this.isRunning) {
            this.isRunning = false;
            clearInterval(this.timerInterval);
            this.elements.startBtn.disabled = false;
            this.elements.pauseBtn.disabled = true;
        }
    }

    resetTimer() {
        this.pauseTimer();
        this.timeLeft = 25 * 60;
        this.updateDisplay();
        this.elements.startBtn.disabled = false;
        this.elements.pauseBtn.disabled = true;
    }

    setTime(minutes) {
        this.pauseTimer();
        this.timeLeft = minutes * 60;
        this.updateDisplay();
        this.elements.startBtn.disabled = false;
        this.elements.pauseBtn.disabled = true;
    }

    updateDisplay() {
        const minutes = Math.floor(this.timeLeft / 60);
        const seconds = this.timeLeft % 60;
        this.elements.timer.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }

    completeSession() {
        this.pauseTimer();
        this.totalSessions++;
        
        // Calculate actual minutes studied from the initial time
        const initialMinutes = Math.ceil(this.timeLeft / 60);
        this.totalMinutes += initialMinutes;
        
        // Update display
        this.elements.totalSessions.textContent = this.totalSessions;
        this.elements.totalTime.textContent = this.totalMinutes;
        
        // Save to localStorage for analytics
        this.saveAnalytics(initialMinutes);
        
        // Play beep sounds
        const beepSound = new Audio("https://www.soundjay.com/button/beep-07.wav");
        
        const playDoubleBeep = async () => {
            try {
                await beepSound.play();
                setTimeout(async () => {
                    beepSound.currentTime = 0;
                    await beepSound.play();
                }, 300);
            } catch (err) {
                console.log('Beep playback failed:', err);
            }
        };
        
        playDoubleBeep();
        
        // Show notification
        if (Notification.permission === 'granted') {
            new Notification('Study Session Complete!', {
                body: 'Take a short break before starting your next session.',
                icon: '/icon.png'
            });
        }

        this.resetTimer();
    }

    // Add new method to save analytics
    saveAnalytics(minutes) {
        const today = new Date().toISOString().split('T')[0]; // Get current date in YYYY-MM-DD format
        
        // Get existing analytics data
        let analytics = JSON.parse(localStorage.getItem('studyAnalytics')) || {};
        
        // Initialize or update today's data
        if (!analytics[today]) {
            analytics[today] = {
                sessions: 0,
                minutes: 0,
                lastUpdate: new Date().toISOString()
            };
        }
        
        // Update today's stats
        analytics[today].sessions += 1;
        analytics[today].minutes += minutes;
        analytics[today].lastUpdate = new Date().toISOString();
        
        // Save back to localStorage
        localStorage.setItem('studyAnalytics', JSON.stringify(analytics));
        
        // Dispatch event for analytics update
        window.dispatchEvent(new CustomEvent('analyticsUpdated', {
            detail: {
                date: today,
                sessions: analytics[today].sessions,
                minutes: analytics[today].minutes
            }
        }));
    }

    // Add method to load analytics
    loadAnalytics() {
        const today = new Date().toISOString().split('T')[0];
        const analytics = JSON.parse(localStorage.getItem('studyAnalytics')) || {};
        
        if (analytics[today]) {
            this.totalSessions = analytics[today].sessions;
            this.totalMinutes = analytics[today].minutes;
            this.elements.totalSessions.textContent = this.totalSessions;
            this.elements.totalTime.textContent = this.totalMinutes;
        }
    }

    // Add new method for custom time
    setCustomTime() {
        const minutes = parseInt(this.elements.customMinutes.value) || 0;
        const seconds = parseInt(this.elements.customSeconds.value) || 0;
        
        // Validate input
        if (minutes === 0 && seconds === 0) {
            alert('Please set a valid time');
            return;
        }
        
        // Set the new time
        this.pauseTimer();
        this.timeLeft = (minutes * 60) + seconds;
        this.updateDisplay();
        
        // Reset inputs
        this.elements.customMinutes.value = '';
        this.elements.customSeconds.value = '';
        
        // Enable start button
        this.elements.startBtn.disabled = false;
        this.elements.pauseBtn.disabled = true;
    }
}

// Initialize timer when page loads
document.addEventListener('DOMContentLoaded', () => {
    // Request notification permission
    if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
        Notification.requestPermission();
    }

    new StudyTimer();
}); 