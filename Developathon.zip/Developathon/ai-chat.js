let isProcessing = false;
const API_URL = 'https://ai-chat-worker.aryantandon2019.workers.dev';

document.addEventListener('DOMContentLoaded', () => {
    const sendButton = document.getElementById('send-message');
    const userInput = document.getElementById('user-input');
    const chatMessages = document.getElementById('chat-messages');
    
    // Initialize chat history with system message
    chatHistory = [{
        role: 'system',
        content: 'You are a helpful AI study assistant. You provide clear, concise explanations and help students understand complex topics.'
    }];

    // Set current topic from localStorage
    const currentTask = localStorage.getItem('currentTask');
    if (currentTask) {
        document.getElementById('current-topic').textContent = currentTask;
        // Add topic context to chat history
        chatHistory.push({
            role: 'system',
            content: `The current study topic is: ${currentTask}`
        });
    }

    // Send message on button click
    sendButton.addEventListener('click', () => {
        if (!isProcessing) {
            sendMessage();
        }
    });

    // Send message on Enter (but allow new lines with Shift+Enter)
    userInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (!isProcessing) {
                sendMessage();
            }
        }
    });
});

async function sendMessage() {
    const userInput = document.getElementById('user-input');
    const message = userInput.value.trim();
    
    if (!message) return;
    
    addMessageToChat('user', message);
    updateChatHistory('user', message);
    userInput.value = '';
    isProcessing = true;

    try {
        addTypingIndicator();

        // Log the request for debugging
        const requestBody = {
            messages: [...chatHistory, {
                role: 'user',
                content: message
            }]
        };
        console.log('Sending request:', requestBody);

        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Origin': 'http://127.0.0.1:5500'
            },
            body: JSON.stringify(requestBody),
            mode: 'cors',
            credentials: 'omit'
        });

        const data = await response.json();
        console.log('API Response:', data);

        removeTypingIndicator();

        if (!data || !data.choices || !data.choices[0] || !data.choices[0].message) {
            console.error('Invalid API response:', data);
            throw new Error('Invalid response format from API');
        }

        const aiResponse = data.choices[0].message.content;
        if (!aiResponse) {
            throw new Error('Empty response from AI');
        }
        updateChatHistory('assistant', aiResponse);
        addMessageToChat('ai', aiResponse);
    } catch (error) {
        console.error('Error:', error);
        removeTypingIndicator();
        const errorMessage = error.message || 'Sorry, I encountered an error. Please try again.';
        addMessageToChat('ai', errorMessage);
    }

    isProcessing = false;
    scrollToBottom();
}

function addMessageToChat(sender, message) {
    const chatMessages = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message flex items-start gap-4';

    const avatar = sender === 'user' ? 'You' : 'AI';
    const avatarColor = sender === 'user' ? 'from-green-500 to-emerald-500' : 'from-indigo-500 to-purple-500';

    messageDiv.innerHTML = `
        <div class="w-8 h-8 rounded-full bg-gradient-to-r ${avatarColor} flex items-center justify-center text-white text-sm font-bold">
            ${avatar}
        </div>
        <div class="flex-1">
            <div class="${sender === 'user' ? 'user-message' : 'ai-message'}">
                <p class="text-gray-800">${message}</p>
            </div>
        </div>
    `;

    chatMessages.appendChild(messageDiv);
    setTimeout(() => messageDiv.classList.add('show'), 50);
    scrollToBottom();
}

function addTypingIndicator() {
    const chatMessages = document.getElementById('chat-messages');
    const typingDiv = document.createElement('div');
    typingDiv.id = 'typing-indicator';
    typingDiv.className = 'chat-message flex items-start gap-4';
    typingDiv.innerHTML = `
        <div class="w-8 h-8 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 flex items-center justify-center text-white text-sm font-bold">
            AI
        </div>
        <div class="flex-1">
            <div class="ai-message">
                <div class="flex gap-2">
                    <span class="animate-bounce">●</span>
                    <span class="animate-bounce" style="animation-delay: 0.2s">●</span>
                    <span class="animate-bounce" style="animation-delay: 0.4s">●</span>
                </div>
            </div>
        </div>
    `;
    chatMessages.appendChild(typingDiv);
    scrollToBottom();
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typing-indicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function scrollToBottom() {
    const chatMessages = document.getElementById('chat-messages');
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

async function getAIResponse(message, topic) {
    try {
        const messages = [...chatHistory, {
            role: 'user',
            content: message
        }].map(msg => ({
            role: msg.role === 'system' ? 'system' : msg.role === 'user' ? 'user' : 'assistant',
            content: msg.content
        }));

        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                messages: messages
            })
        });

        const data = await response.json();

        if (!response.ok) {
            console.error('API Error Details:', data);
            throw new Error(`API request failed: ${response.status} - ${data.error || 'Unknown error'}`);
        }

        console.log('API Response:', data);
        
        if (!data.choices || !data.choices[0] || !data.choices[0].message) {
            throw new Error('Invalid response format from API');
        }

        const aiResponse = data.choices[0].message.content;
        return aiResponse;
    } catch (error) {
        console.error('API Error:', error);
        return 'Sorry, I encountered an error. Please try again in a moment.';
    }
}

function updateLastMessage(content) {
    const lastMessage = document.querySelector('.chat-message:last-child .text-gray-800');
    if (lastMessage) {
        lastMessage.textContent = content;
    }
}

// Add this to store chat history
let chatHistory = [];

function updateChatHistory(role, content) {
    chatHistory.push({ role, content });
    // Keep only last 10 messages to avoid token limits
    if (chatHistory.length > 10) {
        // Keep the system messages and the last 8 conversation messages
        const systemMessages = chatHistory.filter(msg => msg.role === 'system');
        const conversationMessages = chatHistory.filter(msg => msg.role !== 'system').slice(-8);
        chatHistory = [...systemMessages, ...conversationMessages];
    }
} 