// Mood Selection Handling
const moodButtons = document.querySelectorAll('.mood-button');
const confirmButton = document.getElementById('confirmMood');
let selectedMood = null;

moodButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Remove selection from other buttons
        moodButtons.forEach(btn => btn.classList.remove('selected'));
        
        // Select current button
        button.classList.add('selected');
        selectedMood = button.dataset.mood;
        
        // Enable confirm button
        confirmButton.classList.remove('opacity-50', 'pointer-events-none');
    });
});

confirmButton.addEventListener('click', () => {
    if (selectedMood) {
        // Store the mood in localStorage
        localStorage.setItem('currentMood', selectedMood);
        localStorage.setItem('moodTimestamp', new Date().toISOString());
        
        // Redirect to task suggestions page
        window.location.href = 'tasks.html';
    }
}); 