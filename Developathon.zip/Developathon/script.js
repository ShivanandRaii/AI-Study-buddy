// Mobile Menu Toggle
const mobileMenuButton = document.querySelector('.mobile-menu-button');
const nav = document.querySelector('nav');

mobileMenuButton.addEventListener('click', () => {
    const mobileMenu = document.querySelector('.mobile-menu');
    if (mobileMenu) {
        mobileMenu.remove();
    } else {
        const menu = document.createElement('div');
        menu.className = 'mobile-menu';
        menu.innerHTML = `
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#features">Features</a>
            <a href="#">Login</a>
        `;
        nav.appendChild(menu);
    }
});

// Scroll Animations
function reveal() {
    const reveals = document.querySelectorAll('.reveal');
    
    reveals.forEach(element => {
        const windowHeight = window.innerHeight;
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < windowHeight - elementVisible) {
            element.classList.add('active');
        }
    });
}

window.addEventListener('scroll', reveal);

// CTA Button Animation
const ctaButton = document.querySelector('.cta-button');

ctaButton.addEventListener('mouseover', () => {
    ctaButton.classList.add('animate-pulse');
});

ctaButton.addEventListener('mouseout', () => {
    ctaButton.classList.remove('animate-pulse');
});

// Initialize scroll animations
reveal();

// Smooth Scroll for Navigation Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    // Navigation highlight on scroll
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    function highlightNavOnScroll() {
        const scrollY = window.pageYOffset;

        sections.forEach(section => {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop - 80;
            const sectionId = section.getAttribute('id');

            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }

    // Smooth scroll to section
    navLinks.forEach(link => {
        link.addEventListener('click', e => {
            if (link.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const targetId = link.getAttribute('href');
                const targetSection = document.querySelector(targetId);
                if (targetSection) {
                    const headerOffset = 80;
                    const elementPosition = targetSection.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                    
                    window.scrollTo({
                        top: offsetPosition,
                        behavior: "smooth"
                    });
                }
            }
        });
    });

    window.addEventListener('scroll', highlightNavOnScroll);
    highlightNavOnScroll(); // Initial check

    const playGamesBtn = document.getElementById('playGamesBtn');
    if (playGamesBtn) {
        // Hide button if we're on the games page or games-related pages
        const currentPath = window.location.pathname.toLowerCase();
        if (currentPath.includes('games.html') || 
            currentPath.includes('memory-game') || 
            currentPath.includes('word-scramble') || 
            currentPath.includes('quick-quiz')) {
            playGamesBtn.style.display = 'none';
        }
    }
});

// Timer variables
let startTime;
let timerInterval;
let totalMinutesStudied = parseInt(localStorage.getItem('totalMinutesStudied')) || 0;
let isTimerRunning = false;

// Update the minutes studied display
function updateMinutesStudied() {
    const minutesDisplay = document.getElementById('minutesStudied');
    if (minutesDisplay) {
        minutesDisplay.textContent = totalMinutesStudied;
    }
}

// Start timer function
function startTimer() {
    if (!isTimerRunning) {
        startTime = Date.now();
        isTimerRunning = true;
        
        // Update timer display every second
        timerInterval = setInterval(() => {
            const currentTime = Date.now();
            const elapsedTime = Math.floor((currentTime - startTime) / 1000); // in seconds
            
            const hours = Math.floor(elapsedTime / 3600);
            const minutes = Math.floor((elapsedTime % 3600) / 60);
            const seconds = elapsedTime % 60;
            
            // Update timer display
            document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
            document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
            document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
        }, 1000);
    }
}

// Stop timer function
function stopTimer() {
    if (isTimerRunning) {
        clearInterval(timerInterval);
        isTimerRunning = false;
        
        // Calculate minutes studied
        const endTime = Date.now();
        const minutesElapsed = Math.floor((endTime - startTime) / (1000 * 60));
        
        // Update total minutes
        totalMinutesStudied += minutesElapsed;
        localStorage.setItem('totalMinutesStudied', totalMinutesStudied);
        
        // Update display
        updateMinutesStudied();
        
        // Reset timer display
        document.getElementById('hours').textContent = '00';
        document.getElementById('minutes').textContent = '00';
        document.getElementById('seconds').textContent = '00';
    }
}

// Reset timer function
function resetTimer() {
    clearInterval(timerInterval);
    isTimerRunning = false;
    
    // Reset displays
    document.getElementById('hours').textContent = '00';
    document.getElementById('minutes').textContent = '00';
    document.getElementById('seconds').textContent = '00';
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    // Update minutes studied display
    updateMinutesStudied();
    
    // Add event listeners to timer buttons
    document.getElementById('startTimer')?.addEventListener('click', startTimer);
    document.getElementById('stopTimer')?.addEventListener('click', stopTimer);
    document.getElementById('resetTimer')?.addEventListener('click', resetTimer);
});
