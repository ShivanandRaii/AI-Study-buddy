// Task suggestions and motivational tips for each mood
const moodData = {
    Happy: {
        icon: '😊',
        title: "Fantastic! Let's Make the Most of Your Good Mood!",
        message: "Great mood for productive study!",
        tip: "Channel your positive energy into challenging tasks. Your optimistic state can help you tackle complex topics effectively.",
        tasks: [
            {
                title: "Deep Work Session",
                description: "Take advantage of your positive mood to tackle challenging concepts.",
                time: "10 secs", // Demo timer
                priority: "High"
            },
            {
                title: "Group Study",
                description: "Share your energy by organizing a study group session.",
                time: "60 mins",
                priority: "Medium"
            },
            {
                title: "New Topic Introduction",
                description: "Great time to start learning something new!",
                time: "30 mins",
                priority: "Medium"
            }
        ]
    },
    Stressed: {
        icon: '😰',
        title: "I Notice You're Stressed. Let's Take it Easy.",
        message: "Let's break things down into manageable steps.",
        tip: "Take deep breaths. Remember: small steps lead to big achievements. Start with easier tasks to build momentum.",
        tasks: [
            {
                title: "Quick Review Session",
                description: "Review familiar material to build confidence.",
                time: "20 mins",
                priority: "Low"
            },
            {
                title: "Mindful Break",
                description: "Practice deep breathing or quick meditation.",
                time: "10 mins",
                priority: "High"
            },
            {
                title: "Organization Task",
                description: "Organize your study materials and create a simple plan.",
                time: "15 mins",
                priority: "Medium"
            }
        ]
    },
    Tired: {
        icon: '😴',
        title: "Feeling Tired? Let's Work Smarter, Not Harder.",
        message: "We'll focus on lighter, more manageable tasks to keep you productive.",
        tip: "Consider taking a power nap or doing some light exercise to boost your energy. Focus on lighter tasks that don't require intense concentration.",
        tasks: [
            {
                title: "Easy Topic Review",
                description: "Go through familiar concepts at a relaxed pace.",
                time: "15 secs", // Demo timer
                priority: "Medium"
            },
            {
                title: "Active Learning",
                description: "Watch educational videos or listen to subject-related podcasts.",
                time: "30 mins", // Back to normal duration
                priority: "Low"
            },
            {
                title: "Mind Mapping",
                description: "Create visual summaries of key concepts.",
                time: "20 mins", // Back to normal duration
                priority: "Medium"
            }
        ]
    },
    Focused: {
        icon: '🎯',
        title: "You're in the Zone! Let's Make it Count!",
        message: "Perfect state for deep learning!",
        tip: "Make the most of this focused state. Choose your most challenging tasks and create a distraction-free environment.",
        tasks: [
            {
                title: "Complex Problem Solving",
                description: "Work on challenging problems or assignments.",
                time: "50 mins",
                priority: "High"
            },
            {
                title: "Critical Analysis",
                description: "Deep dive into complex topics or research papers.",
                time: "45 mins",
                priority: "High"
            },
            {
                title: "Content Creation",
                description: "Create detailed notes or study materials.",
                time: "40 mins",
                priority: "Medium"
            }
        ]
    },
    Anxious: {
        icon: '😟',
        title: "Feeling Anxious? I'm Here to Help You Through It.",
        message: "Let's take it one step at a time.",
        tip: "Remember to breathe. Break down your work into smaller, manageable tasks. Each small win will help build your confidence.",
        tasks: [
            {
                title: "Structured Review",
                description: "Go through well-organized notes or summaries.",
                time: "20 mins",
                priority: "Medium"
            },
            {
                title: "Anxiety Management",
                description: "Practice calming techniques or take a short walk.",
                time: "15 mins",
                priority: "High"
            },
            {
                title: "Simple Tasks",
                description: "Complete straightforward, achievable assignments.",
                time: "25 mins",
                priority: "Low"
            }
        ]
    },
    Energetic: {
        icon: '⚡',
        title: "Awesome Energy! Let's Put it to Good Use!",
        message: "Great energy for active learning!",
        tip: "Channel your energy into interactive learning methods. Try teaching concepts to others or engaging in dynamic study activities.",
        tasks: [
            {
                title: "Active Problem Solving",
                description: "Work on practice problems or practical exercises.",
                time: "40 mins",
                priority: "High"
            },
            {
                title: "Interactive Learning",
                description: "Create flashcards or participate in study discussions.",
                time: "35 mins",
                priority: "Medium"
            },
            {
                title: "Project Work",
                description: "Work on hands-on projects or experiments.",
                time: "45 mins",
                priority: "High"
            }
        ]
    }
};

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    const currentMood = localStorage.getItem('currentMood');
    if (!currentMood) {
        window.location.href = 'mood.html';
        return;
    }

    const moodInfo = moodData[currentMood];
    
    // Update UI with mood-specific content
    document.getElementById('moodIcon').textContent = moodInfo.icon;
    document.getElementById('moodTitle').textContent = moodInfo.title;
    document.getElementById('moodMessage').textContent = moodInfo.message;
    document.getElementById('motivationalTip').textContent = moodInfo.tip;

    // Generate task cards
    const taskContainer = document.getElementById('taskContainer');
    moodInfo.tasks.forEach(task => {
        const taskCard = `
            <div class="task-card mb-6">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h3 class="text-xl font-semibold mb-2">${task.title}</h3>
                        <p class="text-gray-600 mb-4">${task.description}</p>
                    </div>
                    <span class="task-time">${task.time}</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-sm text-gray-500">Priority: ${task.priority}</span>
                    <button type="button" class="start-task-btn" onclick="startTask('${task.title}', '${task.time}')">
                        Start Task
                    </button>
                </div>
            </div>
        `;
        taskContainer.innerHTML += taskCard;
    });

    // Display completed tasks
    displayCompletedTasks();
});

function startTask(taskTitle, duration) {
    const currentMood = localStorage.getItem('currentMood');
    const task = {
        task: taskTitle,
        duration: duration,
        mood: currentMood,
        completedAt: new Date().toISOString()
    };
    
    // Save completed task
    const completedTasks = JSON.parse(localStorage.getItem('completedTasks') || '[]');
    completedTasks.push(task);
    localStorage.setItem('completedTasks', JSON.stringify(completedTasks));
    
    // Save mood to history
    const moodHistory = JSON.parse(localStorage.getItem('moodHistory') || '[]');
    moodHistory.push({
        mood: currentMood,
        date: new Date().toISOString().split('T')[0],
        timestamp: new Date().toISOString()
    });
    localStorage.setItem('moodHistory', JSON.stringify(moodHistory));
    
    // Redirect to timer
    window.location.href = 'timer.html';
}

function displayCompletedTasks() {
    const completedTasksContainer = document.getElementById('completedTasksContainer');
    const completedTasks = JSON.parse(localStorage.getItem('completedTasks') || '[]');
    const currentMood = localStorage.getItem('currentMood');
    
    if (completedTasks.length === 0) {
        completedTasksContainer.innerHTML = `
            <p class="text-gray-500 text-center py-4">No completed tasks yet</p>
        `;
        return;
    }

    // Filter tasks for current mood and sort by completion time
    const moodCompletedTasks = completedTasks.filter(task => {
        const taskTitle = task.task;
        return moodData[currentMood].tasks.some(t => t.title === taskTitle);
    }).sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt));

    if (moodCompletedTasks.length === 0) {
        completedTasksContainer.innerHTML = `
            <p class="text-gray-500 text-center py-4">No completed tasks for ${currentMood} mood yet</p>
        `;
        return;
    }

    completedTasksContainer.innerHTML = moodCompletedTasks.map(task => `
        <div class="completed-task-card fade-in">
            <div class="task-info">
                <span class="completion-check">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                </span>
                <div class="flex-grow">
                    <h3 class="font-semibold text-gray-900 mb-1">${task.task}</h3>
                    <p class="text-sm text-gray-500">Completed on ${new Date(task.completedAt).toLocaleString('en-US', { 
                        weekday: 'long',
                        month: 'short',
                        day: 'numeric',
                        hour: 'numeric',
                        minute: 'numeric',
                        hour12: true
                    })}</p>
                </div>
                <span class="completed-badge mood-${currentMood.toLowerCase()}">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    ${currentMood} Mood
                </span>
            </div>
        </div>
    `).join('');
}

function updateTaskContainer(tasks) {
    const taskContainer = document.getElementById('taskContainer');
    if (tasks.length === 0) {
        taskContainer.innerHTML = `
            <p class="text-gray-500 text-center py-4">All tasks completed! Great job! 🎉</p>
        `;
        return;
    }

    taskContainer.innerHTML = tasks.map(task => `
        <div class="task-card mb-6">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <h3 class="text-xl font-semibold mb-2">${task.title}</h3>
                    <p class="text-gray-600 mb-4">${task.description}</p>
                </div>
                <span class="task-time">${task.time}</span>
            </div>
            <div class="flex justify-between items-center">
                <span class="text-sm text-gray-500">Priority: ${task.priority}</span>
                <button type="button" class="start-task-btn" onclick="startTask('${task.title}', '${task.time}')">
                    Start Task
                </button>
            </div>
        </div>
    `).join('');
} 