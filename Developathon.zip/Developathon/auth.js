import { auth } from './config.js';
import { GoogleAuthProvider, signInWithPopup, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';

class Auth {
    constructor() {
        this.provider = new GoogleAuthProvider();
        // Add scopes if needed
        this.provider.addScope('profile');
        this.provider.addScope('email');
        
        // Add login button listener
        document.getElementById('googleLogin')?.addEventListener('click', () => this.signInWithGoogle());
        
        // Listen for auth state changes
        onAuthStateChanged(auth, (user) => {
            if (user) {
                this.updateUI(true, user);
            } else {
                this.updateUI(false);
            }
        });
    }

    async signInWithGoogle() {
        const loginBtn = document.getElementById('googleLogin');
        try {
            // Show loading state
            loginBtn.disabled = true;
            loginBtn.innerHTML = '<span>Signing in...</span>';
            
            // Configure sign-in options
            this.provider.setCustomParameters({
                prompt: 'select_account'
            });
            
            const result = await signInWithPopup(auth, this.provider);
            const user = result.user;
            console.log('Successfully signed in:', user.email);
        } catch (error) {
            console.error('Error signing in with Google:', error);
            alert(`Sign-in error: ${error.message}`);
        } finally {
            // Reset button
            loginBtn.disabled = false;
            loginBtn.innerHTML = `
                <span class="flex items-center">
                    <svg class="w-5 h-5 mr-2" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M12.545,10.239v3.821h5.445c-0.712,2.315-2.647,3.972-5.445,3.972c-3.332,0-6.033-2.701-6.033-6.032s2.701-6.032,6.033-6.032c1.498,0,2.866,0.549,3.921,1.453l2.814-2.814C17.503,2.988,15.139,2,12.545,2C7.021,2,2.543,6.477,2.543,12s4.478,10,10.002,10c8.396,0,10.249-7.85,9.426-11.748L12.545,10.239z"/>
                    </svg>
                    Sign in
                </span>
            `;
        }
    }

    async signOut() {
        try {
            await auth.signOut();
            console.log('Signed out successfully');
        } catch (error) {
            console.error('Error signing out:', error);
        }
    }

    updateUI(isLoggedIn, user = null) {
        const loginBtn = document.getElementById('googleLogin');
        const userInfo = document.getElementById('userInfo');
        
        if (isLoggedIn && user) {
            loginBtn?.classList.add('hidden');
            userInfo?.classList.remove('hidden');
            
            // Add sign out button next to email
            userInfo.innerHTML = `
                <span class="text-gray-700 mr-4">${user.email}</span>
                <button onclick="auth.signOut()" class="text-sm text-gray-600 hover:text-indigo-600">
                    Sign Out
                </button>
            `;

            // Store user data if needed
            localStorage.setItem('user', JSON.stringify({
                email: user.email,
                displayName: user.displayName,
                photoURL: user.photoURL
            }));
        } else {
            loginBtn?.classList.remove('hidden');
            userInfo?.classList.add('hidden');
            localStorage.removeItem('user');
        }
    }
}

// Initialize auth when document loads
const auth = new Auth();
window.auth = auth; // Make auth globally available for the sign-out button 