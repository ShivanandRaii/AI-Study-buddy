class ChatInterface {
    constructor() {
        this.messages = document.getElementById('messages');
        this.chatForm = document.getElementById('chatForm');
        this.userInput = document.getElementById('userInput');
        this.chatHistory = [];

        this.chatForm.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // Add initial message
        this.addMessage({
            role: 'assistant',
            content: 'Hi! I\'m your study assistant. How can I help you today?'
        });
    }

    async handleSubmit(e) {
        e.preventDefault();
        const userMessage = this.userInput.value.trim();
        if (!userMessage) return;

        // Add user message to chat
        this.addMessage({
            role: 'user',
            content: userMessage
        });

        // Clear input
        this.userInput.value = '';

        // Show typing indicator
        this.showTypingIndicator();

        try {
            // Make API call to your backend
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message: userMessage,
                    history: this.chatHistory
                })
            });

            const data = await response.json();
            
            // Remove typing indicator
            this.removeTypingIndicator();

            // Add assistant response
            this.addMessage({
                role: 'assistant',
                content: data.response
            });

        } catch (error) {
            console.error('Error:', error);
            this.removeTypingIndicator();
            this.addMessage({
                role: 'assistant',
                content: 'Sorry, I encountered an error. Please try again.'
            });
        }
    }

    addMessage(message) {
        // Add to history
        this.chatHistory.push(message);

        // Create message element
        const messageDiv = document.createElement('div');
        messageDiv.className = `flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`;

        const contentDiv = document.createElement('div');
        contentDiv.className = `max-w-[80%] rounded-xl p-4 ${
            message.role === 'user' 
                ? 'bg-indigo-500 text-white' 
                : 'bg-gray-100 text-gray-800'
        }`;
        contentDiv.textContent = message.content;

        messageDiv.appendChild(contentDiv);
        this.messages.appendChild(messageDiv);

        // Scroll to bottom
        this.messages.scrollTop = this.messages.scrollHeight;
    }

    showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.id = 'typingIndicator';
        indicator.className = 'flex justify-start';
        indicator.innerHTML = `
            <div class="max-w-[80%] rounded-xl p-4 bg-gray-100">
                <div class="flex gap-2">
                    <div class="w-2 h-2 rounded-full bg-gray-400 animate-bounce"></div>
                    <div class="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style="animation-delay: 0.2s"></div>
                    <div class="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style="animation-delay: 0.4s"></div>
                </div>
            </div>
        `;
        this.messages.appendChild(indicator);
        this.messages.scrollTop = this.messages.scrollHeight;
    }

    removeTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.remove();
        }
    }
}

// Initialize chat when page loads
document.addEventListener('DOMContentLoaded', () => {
    new ChatInterface();
}); 