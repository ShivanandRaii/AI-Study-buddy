class QuizGame {
    constructor() {
        // Game state
        this.score = 0;
        this.currentQuestion = 0;
        this.timeLeft = 15;
        this.timerInterval = null;
        this.correctAnswers = 0;
        this.isProcessingAnswer = false;
        
        // Quiz questions
        this.questions = [
            {
                question: "What is the most effective study technique?",
                options: [
                    "Active Recall",
                    "Passive Reading",
                    "Highlighting Text",
                    "Cramming"
                ],
                correct: 0
            },
            {
                question: "How long should an ideal study break be?",
                options: [
                    "5-10 minutes",
                    "15-20 minutes",
                    "30-40 minutes",
                    "1 hour"
                ],
                correct: 1
            },
            {
                question: "What is the Pomodoro Technique?",
                options: [
                    "Study while eating tomatoes",
                    "25 minutes work, 5 minutes break",
                    "Study only at night",
                    "Study with music"
                ],
                correct: 1
            },
            {
                question: "Which is a good study environment?",
                options: [
                    "Noisy café",
                    "Bed",
                    "Quiet library",
                    "Loud music"
                ],
                correct: 2
            },
            {
                question: "What's the best time to study?",
                options: [
                    "Late night",
                    "Early morning",
                    "During meals",
                    "When you feel most alert"
                ],
                correct: 3
            },
            {
                question: "How often should you review material?",
                options: [
                    "Once before exam",
                    "Every day",
                    "Never",
                    "Spaced intervals"
                ],
                correct: 3
            },
            {
                question: "What's the best way to memorize information?",
                options: [
                    "Mnemonics",
                    "Reading repeatedly",
                    "Writing once",
                    "Not taking notes"
                ],
                correct: 0
            },
            {
                question: "How should you organize study materials?",
                options: [
                    "Don't organize",
                    "By subject and topic",
                    "By color",
                    "Randomly"
                ],
                correct: 1
            },
            {
                question: "What helps maintain focus while studying?",
                options: [
                    "Social media breaks",
                    "No breaks at all",
                    "Regular short breaks",
                    "TV in background"
                ],
                correct: 2
            },
            {
                question: "Best practice for note-taking?",
                options: [
                    "Write everything",
                    "Write nothing",
                    "Key points only",
                    "Copy friends' notes"
                ],
                correct: 2
            }
        ];

        // DOM elements
        this.elements = {
            question: document.getElementById('question'),
            options: document.getElementById('options'),
            score: document.getElementById('score'),
            timer: document.getElementById('timer'),
            questionNumber: document.getElementById('questionNumber'),
            feedback: document.getElementById('feedback'),
            nextBtn: document.getElementById('nextBtn'),
            progressBar: document.getElementById('progressBar'),
            resultsModal: document.getElementById('resultsModal'),
            finalScore: document.getElementById('finalScore'),
            correctAnswers: document.getElementById('correctAnswers'),
            playAgainBtn: document.getElementById('playAgainBtn')
        };

        // Bind event listeners
        this.elements.nextBtn.addEventListener('click', () => this.nextQuestion());
        this.elements.playAgainBtn.addEventListener('click', () => this.startGame());

        // Start game
        this.startGame();
    }

    startGame() {
        clearInterval(this.timerInterval);
        this.score = 0;
        this.currentQuestion = 0;
        this.correctAnswers = 0;
        this.isProcessingAnswer = false;
        this.elements.resultsModal.classList.add('hidden');
        this.updateDisplay();
        this.showQuestion();
    }

    showQuestion() {
        const question = this.questions[this.currentQuestion];
        this.elements.question.textContent = question.question;
        this.elements.options.innerHTML = '';
        
        this.elements.timer.classList.remove('text-red-600');
        
        clearInterval(this.timerInterval);
        this.startTimer();
        
        question.options.forEach((option, index) => {
            const button = document.createElement('button');
            button.className = 'option-button w-full p-4 text-left rounded-xl border-2 border-gray-200 transition-all duration-300';
            button.textContent = option;
            button.disabled = false;
            
            button.addEventListener('mousedown', (e) => {
                if (button.disabled || this.isProcessingAnswer) return;
                this.handleAnswer(index);
            }, { once: true });
            
            this.elements.options.appendChild(button);
        });

        const progress = ((this.currentQuestion + 1) / this.questions.length) * 100;
        this.elements.progressBar.style.width = `${progress}%`;
    }

    handleAnswer(selectedIndex) {
        if (this.isProcessingAnswer) return;
        this.isProcessingAnswer = true;
        
        clearInterval(this.timerInterval);
        
        const question = this.questions[this.currentQuestion];
        const buttons = this.elements.options.querySelectorAll('button');
        
        buttons.forEach(button => {
            button.disabled = true;
            button.classList.add('pointer-events-none');
        });
        
        if (selectedIndex === question.correct) {
            buttons[selectedIndex].classList.add('correct-answer');
            this.score += 10;
            this.correctAnswers++;
            this.elements.feedback.textContent = 'Correct! +10 points';
            this.elements.feedback.className = 'text-lg font-medium text-green-600';
        } else {
            buttons[selectedIndex].classList.add('wrong-answer');
            buttons[question.correct].classList.add('correct-answer');
            this.elements.feedback.textContent = 'Wrong answer!';
            this.elements.feedback.className = 'text-lg font-medium text-red-600';
        }

        this.elements.nextBtn.classList.remove('hidden');
        this.updateDisplay();
    }

    nextQuestion() {
        clearInterval(this.timerInterval);
        this.currentQuestion++;
        this.elements.nextBtn.classList.add('hidden');
        this.elements.feedback.textContent = '';
        this.isProcessingAnswer = false;
        
        if (this.currentQuestion < this.questions.length) {
            this.showQuestion();
        } else {
            this.endGame();
        }
    }

    startTimer() {
        clearInterval(this.timerInterval);
        this.timeLeft = 15;
        this.elements.timer.textContent = `0:${this.timeLeft.toString().padStart(2, '0')}`;
        
        this.timerInterval = setInterval(() => {
            if (this.timeLeft <= 0) {
                clearInterval(this.timerInterval);
                this.handleTimeUp();
                return;
            }
            
            this.timeLeft--;
            if (this.timeLeft <= 5) {
                this.elements.timer.classList.add('text-red-600');
            } else {
                this.elements.timer.classList.remove('text-red-600');
            }
            
            this.elements.timer.textContent = `0:${this.timeLeft.toString().padStart(2, '0')}`;
        }, 1000);
    }

    handleTimeUp() {
        if (this.isProcessingAnswer) return;
        
        const buttons = this.elements.options.querySelectorAll('button');
        buttons.forEach(button => {
            button.disabled = true;
            button.classList.add('pointer-events-none');
        });
        
        const question = this.questions[this.currentQuestion];
        buttons[question.correct].classList.add('correct-answer');
        
        this.elements.feedback.textContent = 'Time\'s up!';
        this.elements.feedback.className = 'text-lg font-medium text-yellow-600';
        
        this.elements.nextBtn.classList.remove('hidden');
        this.isProcessingAnswer = true;
    }

    updateDisplay() {
        this.elements.score.textContent = this.score;
        this.elements.questionNumber.textContent = `${this.currentQuestion + 1}/${this.questions.length}`;
    }

    endGame() {
        clearInterval(this.timerInterval);
        this.elements.finalScore.textContent = this.score;
        this.elements.correctAnswers.textContent = `${this.correctAnswers}/${this.questions.length}`;
        this.elements.resultsModal.classList.remove('hidden');
    }
}

// Initialize game when page loads
document.addEventListener('DOMContentLoaded', () => {
    new QuizGame();
}); 