# Mood-Based Productivity App - Page Flow Documentation

## 0. Tech Stack
- HTML5
- CSS3
- JavaScript

## 1. Landing Page (Home)
Layout components:
- Header with app logo and navigation menu (Home, About, Features, Login)
- Hero section with app introduction
- "Start Tracking Now" CTA button
- Features overview section
- Footer with social links and contact info

## 2. Authentication Page (Optional)
Components:
- Email input field
- Password input field
- Login button
- "Continue as Guest" option
- Sign up link for new users
Note: Skip if using local storage only

## 3. Mood Tracking Page
Layout:
- "How are you feeling today?" prompt
- Grid of mood buttons:
  * Happy 😊
  * Stressed 😰
  * Tired 😴
  * Focused 🎯
  * Anxious 😟
  * Energetic ⚡
- Each mood button animates on hover/selection
- "Confirm Mood" button at bottom

## 4. Task Suggestion Page
Dynamic content based on mood:
- Selected mood display
- 3 suggested tasks:
  * For Tired: "Revise an easy topic" (15 mins)
  * For Focused: "Deep work session" (45 mins)
  * For Stressed: "Short meditation + light revision" (20 mins)
- Each task shows:
  * Task name
  * Time estimate
  * Brief description
- "Start Task" button for each suggestion

## 5. Task Timer Page
Components:
- Current task display
- Countdown timer (default 25 mins)
- Pause/Resume button
- Break reminder alerts
- "Mark as Complete" button
- Progress indicator

## 6. Productivity Analytics Page
Sections:
- Mood trends graph (last 7 days)
- Tasks completed counter
- Daily streak tracker
- Mood-to-productivity correlation
- Weekly/monthly statistics

## 7. Settings Page
Options:
- Theme switcher (Light/Dark)
- Notification preferences
- Timer duration settings
- Data reset option
- Sound on/off toggle

## Technical Notes
- All pages are responsive (mobile-first)
- Use Tailwind UI components
- Store user preferences in local storage
- Implement smooth transitions between pages

